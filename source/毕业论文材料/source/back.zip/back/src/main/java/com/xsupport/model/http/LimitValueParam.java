package com.xsupport.model.http;

/**
 * @author lxc
 * @date 2019/4/30
 * @description
 */
public class LimitValueParam {
}
