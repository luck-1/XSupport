package com.xsupport.jpa.measure;

import com.xsupport.jpa.MyBaseJpaDao;
import com.xsupport.model.measure.Soak;

/**
 * @author lxc
 * @date 2019/4/30
 * @description 浸润测量
 */
public interface SoakMapper extends MyBaseJpaDao<Soak,String> {



}