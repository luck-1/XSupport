package com.xsupport.jpa.manage;

import com.xsupport.jpa.MyBaseJpaDao;
import com.xsupport.model.manage.SysWarn;

/**
 * @author lxc
 * @date 2019/5/1
 * @description 系统异常
 */
public interface SysWarnMapper extends MyBaseJpaDao<SysWarn,String> {



}