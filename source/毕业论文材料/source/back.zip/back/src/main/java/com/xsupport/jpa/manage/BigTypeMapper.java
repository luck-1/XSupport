package com.xsupport.jpa.manage;

import com.xsupport.jpa.MyBaseJpaDao;
import com.xsupport.model.manage.BigType;

/**
 * @author lxc
 * @date 2019/4/30
 * @description 类型
 */
public interface BigTypeMapper extends MyBaseJpaDao<BigType,String> {



}