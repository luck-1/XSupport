<template>
</template>

<script>
  export default {
    name: "interface",

  }
</script>

<style scoped>

</style>
